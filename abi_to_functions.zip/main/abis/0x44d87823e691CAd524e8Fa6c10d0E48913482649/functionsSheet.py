from web3 import Web3
import p_k as key
import json
import functions as f
def MakeAllFeePayment():
	return cont.functions.MakeAllFeePayment().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def MakeAllFuturePayments():
	return cont.functions.MakeAllFuturePayments().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def OverSeerProtocol():
	x = cont.functions.OverSeerProtocol().call()
	f.pen(x,"ask.txt")
	print("OverSeerProtocol"," is ",x)
	return x
def OverSeerProtocolFee():
	x = cont.functions.OverSeerProtocolFee().call()
	f.pen(x,"ask.txt")
	print("OverSeerProtocolFee"," is ",x)
	return x
def Zero():
	x = cont.functions.Zero().call()
	f.pen(x,"ask.txt")
	print("Zero"," is ",x)
	return x
def _feeAmount():
	x = cont.functions._feeAmount().call()
	f.pen(x,"ask.txt")
	print("_feeAmount"," is ",x)
	return x
def _nodeAmount():
	x = cont.functions._nodeAmount().call()
	f.pen(x,"ask.txt")
	print("_nodeAmount"," is ",x)
	return x
def _nodeManager():
	x = cont.functions._nodeManager().call()
	f.pen(x,"ask.txt")
	print("_nodeManager"," is ",x)
	return x
def _totalSupply():
	x = cont.functions._totalSupply().call()
	f.pen(x,"ask.txt")
	print("_totalSupply"," is ",x)
	return x
def _totalSupply_():
	x = cont.functions._totalSupply_().call()
	f.pen(x,"ask.txt")
	print("_totalSupply_"," is ",x)
	return x
def allowance(address_owner,address_spender):
	x = cont.functions.allowance(address_owner,address_spender).call()
	f.pen(x,"ask.txt")
	print("allowance"," is ",x)
	return x
def approve(address_spender,uint256_amount):
	return cont.functions.approve(address_spender,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def balanceOf(address_account):
	x = cont.functions.balanceOf(address_account).call()
	f.pen(x,"ask.txt")
	print("balanceOf"," is ",x)
	return x
def blacklistAddress(address_account,bool_value):
	return cont.functions.blacklistAddress(address_account,bool_value).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def burn(address_account,uint256_amount):
	return cont.functions.burn(address_account,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def cashoutAll():
	return cont.functions.cashoutAll().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def cashoutFee():
	x = cont.functions.cashoutFee().call()
	f.pen(x,"ask.txt")
	print("cashoutFee"," is ",x)
	return x
def cashoutPerc():
	x = cont.functions.cashoutPerc().call()
	f.pen(x,"ask.txt")
	print("cashoutPerc"," is ",x)
	return x
def createNodeWithTokens(string_name):
	return cont.functions.createNodeWithTokens(string_name).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def decimals():
	x = cont.functions.decimals().call()
	f.pen(x,"ask.txt")
	print("decimals"," is ",x)
	return x
def decreaseAllowance(address_spender,uint256_subtractedValue):
	return cont.functions.decreaseAllowance(address_spender,uint256_subtractedValue).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def feeAmount():
	x = cont.functions.feeAmount().call()
	f.pen(x,"ask.txt")
	print("feeAmount"," is ",x)
	return x
def feeToken():
	x = cont.functions.feeToken().call()
	f.pen(x,"ask.txt")
	print("feeToken"," is ",x)
	return x
def increaseAllowance(address_spender,uint256_addedValue):
	return cont.functions.increaseAllowance(address_spender,uint256_addedValue).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def isTradingEnabled():
	x = cont.functions.isTradingEnabled().call()
	f.pen(x,"ask.txt")
	print("isTradingEnabled"," is ",x)
	return x
def joePair():
	x = cont.functions.joePair().call()
	f.pen(x,"ask.txt")
	print("joePair"," is ",x)
	return x
def joeRouterAddress():
	x = cont.functions.joeRouterAddress().call()
	f.pen(x,"ask.txt")
	print("joeRouterAddress"," is ",x)
	return x
def liquidityPoolFee():
	x = cont.functions.liquidityPoolFee().call()
	f.pen(x,"ask.txt")
	print("liquidityPoolFee"," is ",x)
	return x
def migrate(addressls_addresses_,uint256ls_balances):
	return cont.functions.migrate(addressls_addresses_,uint256ls_balances).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def name():
	x = cont.functions.name().call()
	f.pen(x,"ask.txt")
	print("name"," is ",x)
	return x
def nodeAmount():
	x = cont.functions.nodeAmount().call()
	f.pen(x,"ask.txt")
	print("nodeAmount"," is ",x)
	return x
def owner():
	x = cont.functions.owner().call()
	f.pen(x,"ask.txt")
	print("owner"," is ",x)
	return x
def payInPieces(uint256__payments):
	return cont.functions.payInPieces(uint256__payments).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def renounceOwnership():
	return cont.functions.renounceOwnership().buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def rewardsFee():
	x = cont.functions.rewardsFee().call()
	f.pen(x,"ask.txt")
	print("rewardsFee"," is ",x)
	return x
def rewardsPool():
	x = cont.functions.rewardsPool().call()
	f.pen(x,"ask.txt")
	print("rewardsPool"," is ",x)
	return x
def rwSwap():
	x = cont.functions.rwSwap().call()
	f.pen(x,"ask.txt")
	print("rwSwap"," is ",x)
	return x
def swapLiquifyEnabled():
	x = cont.functions.swapLiquifyEnabled().call()
	f.pen(x,"ask.txt")
	print("swapLiquifyEnabled"," is ",x)
	return x
def symbol():
	x = cont.functions.symbol().call()
	f.pen(x,"ask.txt")
	print("symbol"," is ",x)
	return x
def teamPool():
	x = cont.functions.teamPool().call()
	f.pen(x,"ask.txt")
	print("teamPool"," is ",x)
	return x
def teamPoolFee():
	x = cont.functions.teamPoolFee().call()
	f.pen(x,"ask.txt")
	print("teamPoolFee"," is ",x)
	return x
def totalClaimed():
	x = cont.functions.totalClaimed().call()
	f.pen(x,"ask.txt")
	print("totalClaimed"," is ",x)
	return x
def totalSupply():
	x = cont.functions.totalSupply().call()
	f.pen(x,"ask.txt")
	print("totalSupply"," is ",x)
	return x
def transfer(address_to,uint256_amount):
	return cont.functions.transfer(address_to,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def transferFee():
	x = cont.functions.transferFee().call()
	f.pen(x,"ask.txt")
	print("transferFee"," is ",x)
	return x
def transferFrom(address_from,address_to,uint256_amount):
	return cont.functions.transferFrom(address_from,address_to,uint256_amount).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def transferOwnership(address_newOwner):
	return cont.functions.transferOwnership(address_newOwner).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def treasury():
	x = cont.functions.treasury().call()
	f.pen(x,"ask.txt")
	print("treasury"," is ",x)
	return x
def treasuryFee():
	x = cont.functions.treasuryFee().call()
	f.pen(x,"ask.txt")
	print("treasuryFee"," is ",x)
	return x
def updateCashoutFee(uint256_newVal):
	return cont.functions.updateCashoutFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateJoePair(address_newVal):
	return cont.functions.updateJoePair(address_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateJoeRouterAddress(address_newAddress):
	return cont.functions.updateJoeRouterAddress(address_newAddress).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateNodeAmount(uint256_newVal):
	return cont.functions.updateNodeAmount(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateNodeManager(address_newVal):
	return cont.functions.updateNodeManager(address_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateOverSeerProtocol(address_newVal):
	return cont.functions.updateOverSeerProtocol(address_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateOverseer(address_newVal):
	return cont.functions.updateOverseer(address_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateRewardsFee(uint256_newVal):
	return cont.functions.updateRewardsFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateRewardsPool(address_newVal):
	return cont.functions.updateRewardsPool(address_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateTeamFee(uint256_newVal):
	return cont.functions.updateTeamFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateTeamPool(address_newVal):
	return cont.functions.updateTeamPool(address_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateTransferFee(uint256_newVal):
	return cont.functions.updateTransferFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateTreasuryFee(uint256_newVal):
	return cont.functions.updateTreasuryFee(uint256_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def updateTreasuryPool(address_newVal):
	return cont.functions.updateTreasuryPool(address_newVal).buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})
def view_all():
	print("OverSeerProtocol",":",cont.functions.OverSeerProtocol().call())
	print("OverSeerProtocolFee",":",cont.functions.OverSeerProtocolFee().call())
	print("Zero",":",cont.functions.Zero().call())
	print("_feeAmount",":",cont.functions._feeAmount().call())
	print("_nodeAmount",":",cont.functions._nodeAmount().call())
	print("_nodeManager",":",cont.functions._nodeManager().call())
	print("_totalSupply",":",cont.functions._totalSupply().call())
	print("_totalSupply_",":",cont.functions._totalSupply_().call())
	print("cashoutFee",":",cont.functions.cashoutFee().call())
	print("cashoutPerc",":",cont.functions.cashoutPerc().call())
	print("decimals",":",cont.functions.decimals().call())
	print("feeAmount",":",cont.functions.feeAmount().call())
	print("feeToken",":",cont.functions.feeToken().call())
	print("isTradingEnabled",":",cont.functions.isTradingEnabled().call())
	print("joePair",":",cont.functions.joePair().call())
	print("joeRouterAddress",":",cont.functions.joeRouterAddress().call())
	print("liquidityPoolFee",":",cont.functions.liquidityPoolFee().call())
	print("name",":",cont.functions.name().call())
	print("nodeAmount",":",cont.functions.nodeAmount().call())
	print("owner",":",cont.functions.owner().call())
	print("rewardsFee",":",cont.functions.rewardsFee().call())
	print("rewardsPool",":",cont.functions.rewardsPool().call())
	print("rwSwap",":",cont.functions.rwSwap().call())
	print("swapLiquifyEnabled",":",cont.functions.swapLiquifyEnabled().call())
	print("symbol",":",cont.functions.symbol().call())
	print("teamPool",":",cont.functions.teamPool().call())
	print("teamPoolFee",":",cont.functions.teamPoolFee().call())
	print("totalClaimed",":",cont.functions.totalClaimed().call())
	print("totalSupply",":",cont.functions.totalSupply().call())
	print("transferFee",":",cont.functions.transferFee().call())
	print("treasury",":",cont.functions.treasury().call())
	print("treasuryFee",":",cont.functions.treasuryFee().call())
	
global scanners,add,abi,cont,account_1,scanners,net,ch_id,main_tok,file,w3,network,nonce
add = "0x44d87823e691CAd524e8Fa6c10d0E48913482649"
abi = f.reader_C("abi_fold/"+str(add)+".json")
main_all = f.mains()
scanners,net,ch_id,main_tok,file,w3,network = main_all

cont = w3.eth.contract(add,abi = abi)
account_1 = w3.eth.account.privateKeyToAccount(key.p)
nonce = w3.eth.getTransactionCount(account_1.address)