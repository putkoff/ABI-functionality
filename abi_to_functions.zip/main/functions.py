import json
from dotenv import load_dotenv
import os
from web3 import Web3
import pyperclip
import subprocess
import sys
import requests
import os
from hexbytes import HexBytes
def make_all_dirs(x):
	if  is_ls(x) == False:
		x = [x]
	for i in range(0,len(x)):
		if '.' not in x[i]:
			if i ==0:
				x_n = x[i]
			else:
				x_n = create_path(x_n,x[i])
			make_dir(x_n)
		else:
			x_n = create_path(x_n,x[i])
			if exists(x_n) == False:
				pen('',x_n)
	return x_n
def get_alph():
    alph = 'a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,aa,bb,cc,dd,ee,ff,gg,hh,ii,jj,kk,ll,mm,nn,oo,pp,qq,rr,ss,tt,uu,vv,ww,xx,yy,zz,aaa,bbb,ccc,ddd,eee,fff,ggg,hhh,iii,jjj,kkk,lll,mmm,nnn,ooo,ppp,qqq,rrr,sss,ttt,uuu,vvv,www,xxx,yyy,zzz'
    return alph.split(',')
def get_name():
    return os.path.basename(__file__)
def change_path(x):
    os.path.abspath(x)
def get_curr_path():
    return os.getcwd()
def get_parent_dir():
    return str(get_curr_path()).replace('/'+str(get_curr_path()).split('/')[-1],'')
def change_parent_dir():
    return change_gears(get_parent_dir())
def change_gears(x):
    curr = get_curr_path()
    change_path(x)
    return curr
def home_it():
    curr = get_curr_path()
    slash = '\\'
    if '\\' not in str(curr):
        slash = '/'
    change_glob('slash',slash)
    change_glob('home',curr)
    return curr,slash
def check_str(x,y):
    c = ''
    if str(x) != str(y):
        c = y
    return c
def create_path(x,y):
    if x == '':
        return str(y) + str(check_str(str(y),slash))
    return str(x) + str(check_str(x[-1],slash))+str(y)
def check_dir(x):
    return os.path.isdir(x)
def do_all_dir(x):
##    x = x.split(slash)
    print(x)
    m = ''
    for i in range(0,len(x)):
        n = x[i]
        m = create_path(m,n)
        print(m)
        do_the_dir(m)
def do_the_dir(x):
    if check_dir(x) == False:
        make_dir(x)
def check_file(x):
    return os.path.isfile(x)
def do_the_file(x,y,z):
    if check_file(x) == False:
        pen(y,z)
        return y
    return reader(z)
def make_dir(x):
    if check_dir(x) == False:
        os.mkdir(x)
def list_files(x):
    return os.listdir(x)
def copyIt(x,y):
        pen(reader(x),y)
def copy_it(x,y,n):
        pen(reader_C(x),create_path(y,'abi_funs.py'))
def reader_C(file):
	with open(file, "r",encoding="utf-8-sig") as f:
		text = f.read()
		return text
def sites(A):
    U = [A]
    for url in U:
        X = str(U[0])
        r = requests.get(X)
        PS = r.text
        JS = json.loads(PS)['result']
    return JS
def find_it_alph(x,k):
    i = 0
    while str(x[i]) != str(k):
        i = i + 1
    return i
def get_c(x):
        c = ','
        if int(x) == int(0):
                c = ''
        return c
def wrap_up(x,y,z):
        w = str(z)[:-1]+get_c(len(z))+'"'+str(x)+'":"'+str(y)+'"'+str(z)[-1]
        return js_it(w)
def create_wrap_ls(x,y):
        z = json.loads('{}')
        for i in range(0,len(x)):
                z = wrap_up(x[i],y[i],z)
        return z
def check_sum(x):
    return Web3.toChecksumAddress(str(x))
def get_alph():
    alph = 'a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,aa,bb,cc,dd,ee,ff,gg,hh,ii,jj,kk,ll,mm,nn,oo,pp,qq,rr,ss,tt,uu,vv,ww,xx,yy,zz,aaa,bbb,ccc,ddd,eee,fff,ggg,hhh,iii,jjj,kkk,lll,mmm,nnn,ooo,ppp,qqq,rrr,sss,ttt,uuu,vvv,www,xxx,yyy,zzz'
    return alph.split(',')
def create_ask(x,y):
        alph = get_alph()
        n = 'which '+str(y)+' would you like to use?\n'
        for i in range(0,len(x)):
                n = n + str(alph[i]) + ') '+str(x[i])+'\n'
        ask = input(n)
        i = find_it_alph(alph,str(ask))
        return x[i]
def rem_file(x):
        os.remove(x) 
def rem_var():
        if exists('variables/vars.txt') == True:
                rem_file('variables/vars.txt')
def mains():
        global scanners,net,ch_id,main,file,w3,last_api,c_k,hashs_js,expo,dec,network,scan_num
        hashs_js = ""
        last_api = [0,0]
        main = {
        	"avax_test":{"net":"https://api.avax-test.network/ext/bc/C/rpc","chain":"43113","main_tok":"AVAX","scanners":"api-testnet.snowtrace.io"},
        	"polygon":{"net":"https://polygon-rpc.com/","chain":"137","main_tok":"MATIC","scanners":"api.polygonscan.com"},
        	"ethereum":{"net":"https://mainnet.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161","chain":"1","main_tok":"ETH","scanners":"api.etherscan.io"},
        	"cronos_test":{"net":"https://cronos-testnet-3.crypto.org:8545/","chain":"338","main_tok":"TCRO","scanners":"api.cronoscan.com"},
        	"optimism":{"net":"https://kovan.optimism.io","chain":"69","main_tok":"OPT","scanners":"api-kovan.etherscan.io"},
        	"binance":{"net":"https://bsc-dataseed.binance.org/","chain":"56","main_tok":"bsc","scanners":"api.bscscan.com"}
                }
        scan = ["avax_test","polygon","ethereum","cronos_test","optimism","binance"]
        var_names = ['scanners','net','ch_id','main_tok','file','w3','network']
        file = 'variables/vars.txt'
        if exists('variables/vars.txt') == False:
                network = create_ask(scan,'network')
                all = main[network]
                scanners,net,ch_id,main_tok,w3 = all["scanners"],all["net"],all["chain"],all["main_tok"],Web3(Web3.HTTPProvider(all["net"]))
                vars = [scanners,net,ch_id,main_tok,file,w3,network]
                pen(create_wrap_ls(var_names,vars),'variables/vars.txt')
        fi = js_it(reader('variables/vars.txt'))
        return fi['scanners'],fi['net'],fi['ch_id'],fi['main_tok'],fi['file'],Web3(Web3.HTTPProvider(fi["net"])),fi['network']
def change_gears(x): #(dir) changes directory and spits back the previous one
    y = os.getcwd()
    os.chdir(x)
    return y
def create_path(x,y):
    home = os.getcwd()
    n = '/'
    if '\\' in home:
        n = '\\'
    ###print(x[-2:])
    while x[-2:] == n:
        x = x[:-2]
    z = x + n + y
    return z
def choose_wall():
	dyn_walls()
	q = input('which wallet would you like to use?')
	if nos(q) == False:
		return int(-1)
	return int(q) - int(1)

def send_all(x,n,k):
    
    a,p = get_walls(choose_wall())
    for i in range(n,k):
        if str(x) != str(a[i]):
            var = [a[i],x,p[i]]
            strs = ['account_1','account_2','private_key1']
            for i in range(0,len(strs)):
                change_glob(strs[i],var[i])
            sv_env(p)
            #print(p)
            change_glob('maxxi',1)
            send()
def back_pro(x):
    p = subprocess.Popen([sys.executable, str(x)],stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return
def blanks():
    js = exists_js('adds.txt')
    a,n = js['adds'],js['names']
    js['names'] = []
    for i in range(0,len(a)):
        js['names'].append(str(''))
    pen(js,'adds.txt')
def create_em():
    from eth_account import Account
    import secrets
    from hexbytes import HexBytes
    import json
    js = exists_js('adds.txt')
    priv = secrets.token_hex(32)
    private_key = priv
    acct = Account.from_key(private_key)
    ls = private_key,acct.address
    js['adds'].append(ls[1])
    js['priv'].append(ls[0])
    js['names'].append('')
    pen(js,'adds.txt')
    back_pro(js)
def clip_it(x):
    text = str(x)
    os.system("echo '{}' | xclip -selection clipboard".format(text))
def change_glob(x,v):
    globals()[x] = v
def globulars():
    global wall_file,w3,main,mains,ch_id,net,account_1,private_key1,account_2,a,p,maxxi
    wall_file = ''
    w3 = ''
    maxxi = 0
    main = ''
    mains = ''
    net = ''
    ch_id = ''
    account_1 = ''
    account_2 = ''
    private_key1 = ''
    a = ''
    p = ''
def expos():
    return float(1e-18)
def wall_check():
    if exists('adds.txt') == False:
        pen('{"adds":[],"priv":[],"names":[]}','adds.txt')
    return js_read('adds.txt')  
def is_ls(ls):
    if type(ls) is list:
        return True
    return False
def exists_js(file):
    if exists(file) == False:
        x = js_it('{}')
        if is_ls(file) is True:
            x = (file[1])
        pen(x,file)
        return x
    else:
        x = js_it(str(reader_B(file)))
    return x
def exists(file):
    try:
        x = reader_B(file)
        return True
    except IOError:
        return False
def timer(i):
    return int(i) + int(1)
def hx(x):
    print(exists_js('adds.txt'))
    a = json.loads(str(exists_js('adds.txt')).replace("'",'"'))
    k = 'adds','priv'
    
    for i in range(0,2):
        x = "".join(["{:02X}".format(b) for b in HexBytes("0x"+str(x))])
        a[k[i]].append(str(x))
    
def pen(x,p):
    with open(p, 'w',encoding='UTF-8') as f:
        
        return f.write(str(x))
def reader(file):
    with open(file, 'r') as f:
        text = f.read()
        return text
def reader_B(file):
    with open(file, 'r',encoding='UTF-8') as f:
        text = f.read()
        return text
def get_walls():
    js = exists_js('adds.txt')
    a = js['adds']
    p = js['priv']
    return a,p
def js_it(x):

    return json.loads(str(x).replace("'",'"'))
def js_read(x):
    return js_it(reader_B(x))
def sv_env(x):
    if is_num(x) == True:
        ls = exists_js('adds.txt')
        x = ls['priv'][x]
    pen('MNEMONIC=\nPRIVATE_KEY='+str(x),'.env')
def get_env(x):
    load_dotenv()
    load_dotenv('.env')
    p = os.environ.get("privateKey")
def find_it(ls,k):
    for i in range(0,len(ls)):
        if str(k) == ls[i]:
            return int(int(i) - int(1))
        i = timer(i)
    return None
def set_net(x):
    return Web3(Web3.HTTPProvider(x))
def get_bal(w3,x):
    return w3.eth.getBalance(x)
def send():
    maxx = get_bal(account_1)
    gas = float(100000)
    maxx = float(float(maxx)-float(float(maxx)*float(0.05)))*float(1e-18)
    if maxxi == 0:
        amt = input_it('how much would you like to send?\n you can send a max of '+str(maxx))
    else:
        amt = maxx
        #print('sending a max: '+str(maxx)+' to '+str(account_2))
    nonce = w3.eth.getTransactionCount(account_1)
    tx = {
        'nonce': nonce,
        'to': account_2,
        'value': w3.toWei(float(amt), 'ether'),
        'gas':100000,
        'gasPrice': 15000000000000,
        'chainId': 338
    }
    #build a transaction in a dictionary
    bal = w3.eth.getBalance(account_1)
    #print(bal)
    #sign the transaction
    signed_tx = w3.eth.account.sign_transaction(tx, private_key1)
    #send transaction
    tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
    #get transaction hash
    #print(w3.toHex(tx_hash))
    change_glob('maxxi',0)
def zeros():
    a,p = get_walls()
    n = 0
    for i in range(n,len(a)):
        w = a[i]
        if float(get_bal(w))*expos() == float(0.0):
            clip_it(w)
            import webbrowser
            webbrowser.open("https://cronos.org/faucet")
            q = input_it("enter")
        n = timer(n)
        ##print(i+1,' - ',a[i],' has a balance of ',str(round(float(get_bal(a[i]))*expos(),4)),main)
def is_num(x):
    try:
        i = float(x)
        i = int(x)
        return True
    except:
        return False
def re_wa():
    return 
def disp_dyn():
    exists_js(str(wall_file))
def dyn_walls():
    a,p = get_walls()
    #print(re_wa())
    if re_wa() == None:
        new = '"0 - create new wallet"'
        for i in range(0,len(a)):
            new = new +',\n"'+ str(str(i+1)+' - '+str(a[i])+' has a balance of '+str(round(float(get_bal(a[i]))*expos(),4))+' '+str(main))+'"'
            #print(new)
            nn = i
        pen(new.replace('"','').replace(',',''),str(wall_file))
        pen(nn,'num_'+str(wall_file))
    
def name_it(x):
    txt = exists_js('adds.txt')
    i = x
    a = txt['adds']
    n = txt['names']
    if is_num(x) == False:
        i = find_it(a,x)
    
    new = input_it("name_wall")
    if str(new) != '' and str(new) != ' ' and str(new) != 'n':
        if len(a) > len(n):
             txt['names'][i].append(str(new))
        else:
             txt['names'][i] = str(new)
        pen(txt,'adds.txt')
        return new
    return n
def nos(x):
    x.append(['N']).append('NO')
    if str(x) not in str(x[1:]):
        if  x[0] not in str(x[1:]):
            return True
    return False
def input_it(x):
    y = js_it({"which":"which account would you like to use?","zeros":"wanna start with the zero wallets first?(enter/n)","test":"getting test coins?(enter/n)","new_wall":"did you want to grab some new wallets?(how many?/n)","enter":"press enter when ready","name_wall":"what would you like to name the wallet?(name/(enter,n)"})
    if str(x) in y:
        x = y[x]
    return input(str(x)+':\n')
    
def pic_walls():
    dyn_walls()
    #print(disp_dyn())
    a_num = input_it("which")
    
    if a_num == int(0):
        from create import ls
        account_1 = ls[1]
        private_key1 = ls[0]
        sv_env(-1)
    else:
        a,p = get_walls()
        a_num = int(a_num)-int(1)
        account_1 = a[a_num]
        private_key1 = p[a_num]
        sv_env(a_num)
        a,p = get_walls()
    #print(account_1,'chosen')
    return account_1,private_key1
def ch_main(x):
    y = js_read('adds.txt')
    y['main'] = x
    pen(y,'adds.txt')
def change_main():
    q = input_it('did you want to keep '+str(get_main())+' as your main acct?(enter/n)')
    if str(q) == '':
        return get_main()
    else:
        dyn_walls()
        #print(re_wa())
        a_num = int(input_it("which")) - int(1)
        y = js_read('adds.txt')
        y['main'] = a[a_num]
        pen(y,'adds.txt')
        return get_main()
def get_main():
    return js_read('adds.txt')['main']
def get_new_gas():
    q_3 = 'n'
    #name_it("name_wall")
    q = input_it("new_wall")
    q_2 = input_it("test")
    if q_2 != 'n':
        q_3 = input_it('zeros')
        if q_3 != 'n':
            zeros()
    if str(q) != 'n':
        if is_num(q) == False:
            q = 1
        for i in range(0,int(q)):
            create_em()
            a = js_read('adds.txt')['adds'][-1]
            clip_it(a)
            if str(q_2) != 'n':
                import webbrowser
                webbrowser.open("https://cronos.org/faucet")
                input_it("enter")
            i = timer(i)

