import functions as f
import grabABI as getABI
import fun_get as fun
import parse_funs as parse
import json
def grabABI(x):
    add = f.check_sum(x)
    y = f.make_all_dirs(['abis',str(add),'abi.json'])
    getABI.add,getABI.scanners,getABI.net,getABI.ch_id,getABI.main_tok,getABI.file,getABI.w3,getABI.network =add,scanners,net,ch_id,main_tok,file,w3,network
    f.pen(getABI.get_abi(),y)
    return y
def breakDown(x):
    y = f.make_all_dirs(['abis',str(x),'variables.json'])
    f.pen(fun.go(x,json.loads(f.reader(grabABI(x)))),y)
    return y
def parseIt(x):
    y = f.make_all_dirs(['abis',str(x),'functionsSheet.py'])
    z = f.make_all_dirs(['abis',str(x),'functionCalls.json'])
    funs,asks,call,fun_all,fun_sheet = parse.parse_it(x,json.loads(f.reader(breakDown(x)).replace("'",'"'))["funs"])
    funCalls = {"names":["funs","asks","call","fun_all"],"funs":funs,"asks":asks,"call":call,"fun_all":fun_all}
    f.pen(fun_sheet,y)
    f.pen(funCalls,z)
    createCurrent()
def createCurrent():
    files = ['variables.json','abi.json','functionsSheet.py','functionCalls.json']
    for i in range(0,len(files)):
        print(f.make_all_dirs([home,'abis',str(add),files[i]]))
        f.copyIt(f.make_all_dirs([home,'abis',str(add),files[i]]),f.make_all_dirs([home,'current',files[i]]))
global scanners,net,ch_id,main_tok,file,w3,network,home,slash
scanners,net,ch_id,main_tok,file,w3,network = f.mains()
home,slash = f.home_it()
ad = '0x44d87823e691CAd524e8Fa6c10d0E48913482649'
add = f.check_sum(ad)
parseIt(add)
