#!/opt/rh/rh-python35/root/usr/python
import os
import os.path
import requests
import json
import time
import datetime
import requests
import math
import gc
import sys
import json
import pyperclip
import subprocess
import web3
from dotenv import load_dotenv
from hexbytes import HexBytes
from web3.contract import ContractEvent
from web3.contract import Contract
from web3._utils.events import get_event_data
from web3 import Web3
from web3.auto import w3
from eth_utils import event_abi_to_log_topic
from attributedict.collections import AttributeDict
from eth_log.models.contract import Contract
from hexbytes import HexBytes
from ast import literal_eval
import eth_event
def get_hex_data(x):
    hex = x
    return int(hex, 16)
def get_c(i):
    c = ''
    if i != 0:
        c = ',\n'
    return c
def js_wrap_it(x,y,i):
    c = get_c(i)
    return str(c)+'"'+str(x)+'":'+str(y)+''
def try_it_js(x,js):
    try:
        n = js[x]
        return True
    except:
        return False
def head_hex(x):
    h = '0x'
    if h in str(x):
        x = str(x)[2:]
    else:
        x = read_hex(str(h+str(x)))
    return x
def timer(i):
    return int(int(i)+ int(1))
def hash_update(x,y):
    x = js_it('{'+str(x)[1:-1]+js_wrap_it(str(y),'{}',len(x))+'}')
    x["hash_pairs"] = js_it('{'+str(x["hash_pairs"])[1:-1] +js_wrap_it(str(y),'[],"txns":[]',len(x["hash_pairs"]))+'}')
    x["hashs"].append(str(y))
    x = js_it(x)
    change_glob('hashs_js',x)
    return x
def add_update(x,y,z):
    x = js_it(x)
    x[str(y)] = js_it(str(x[str(y)])[-1] +js_wrap_it(str(z),'{"amt":[],"event":[]}',len(x[str(y)]))+'}')
    x["hash_pairs"][str(y)].append(str(z))
    change_glob('hashs_js',x)
    return x
def js_it(x):
    return json.loads(str(x).replace("'",'"'))
def kek(x):
    st = '"'+str(x)+'"'
    return w3.keccak(text=str(x)).hex()
def c_res():
    change_glob('c_k',int(0))
def c_cou(c_k):
    c_k = timer(c_k)
    change_glob('c_k',int(c_k))
def for_it(x):
    if int(c_k) <= len(x):
        x = c_cou(c_k)
        return True
    else:
        x = c_res()
        return False
def get_events(x):
    x = w3.eth.getFilterLogs(x.filter_id)
    return x
def exists(x):
    try:
        x = reader(x)
        return x
    except:
        return ''
def get_expo(x):
    expo = str('1e')+str('-'+str(x))
    expo = float(str(expo))
    change_glob('expo',expo)
    return expo
def get_dec():
    dec = cont.functions.decimals().call()
    change_glob('dec',str(dec))
    expo = get_expo(dec)
    return dec,expo
def get_abi(x):
    x = js_it(reader_C(x))
    return x
def get_cont(x,y):
    get_abi(y)
    cont = w3.eth.contract(x,abi = abi)
    change_glob('cont',cont)
    return cont
def save_events(x,y):
    c = ''
    if len(x) > 0:
        c = ','
    x = str(exists(y))[:-1]+c+str(x)


    pen(x,y)
def join_it(x,y):
    return str(x)+str(y)
def txt_it(x):
    return str(x) +'.txt'
def js_qu(x):
    if type(x) is not list:
        return '"'+str(x)+'"'
    ls = []
    for i in range(0,len(x)):
        ls.append('"'+str(x[i])+'"')
    return x
def add_js(x,y):
    print(str(x)[:-1] + get_c(len(x)) + str(y)+str(x)[-1])
    return js_it(str(x)[:-1] + get_c(len(x)) + str(y)+str(x)[-1])
def gen_fun(x,y):
    n = ['indexed', 'internalType', 'name', 'type']
    y = y['name']+'('+y['type']+')'
    print(y)
    return y
def catchup():
    while len(event_logs) == 0:
        filt()
def filt():
    i_e()
    filt = w3.eth.filter({"address": pairs,'fromBlock':b,'toBlock':e})
    change_glob('event_logs',w3.eth.get_filter_logs(filt.filter_id)) 
def i_e():
    change_glob('b',e)
    change_glob('e',int(int(e)+int(2048)))
    pen(e,'last_block.txt')
def get_em(net):
    from web3 import Web3, HTTPProvider
    hhhh = Web3(HTTPProvider(net))
    return hhhh.eth.blockNumber
def find_it(x,y):
    if in_it(x,y) == True:
        for i in range(0,len(y)):
            if str(x) == str(y[i]):
                return i
    return False
def in_it(x,y):
    if str(x) in y:
        return True
    return False
def exists(x):
    try:
        x = reader(x)
        return x
    except:
        return '0'
def pen(paper, place):
    with open(place, 'w') as f:
        f.write(str(paper))
        f.close()
        return
def pen_C(paper, place):
    with open(place, 'w',encoding='utf-8-sig') as f:
        f.write(str(paper))
        f.close()
        return
def reader(file):
    with open(file, 'r') as f:
        text = f.read()
        return text
def change_glob(x,v):
    globals()[x] = v 
def get_em(net):
    from web3 import Web3, HTTPProvider
    hhhh = Web3(HTTPProvider(net))
    return hhhh.eth.blockNumber
def i_e():
    change_glob('b',e)
    change_glob('e',int(int(e)+int(2048)))
    pen(e,'last_block.txt')
def filt():
    i_e()
    filt = w3.eth.filter({"address": pairs,'fromBlock':b,'toBlock':e})
    change_glob('event_logs',w3.eth.get_filter_logs(filt.filter_id))
def get_hex_data(x):
    n = len(x)
    hex = x
    return int(hex, n)    
def catchup():
    while len(event_logs) == 0:
        filt()
def read_hex(hb):
    h = "".join(["{:02X}".format(b) for b in hb])
    return '0x'+h
def get_expo(x):
    n = '1e-'+str(get_dec(x))
    return float(n)
def get_txn_data(x):
    string = read_hex(x)
    de = literal_eval(string)
    return de

def get_txn_stuff(x):
    h = read_hex(x.transactionHash)
    l = str(head_hex(h))
    a = x.address
    t = x.topics
    d = x.data
    return h,l,a,t,d
def get_hex_data(x):
    n = len(x)
    hex = x
    return int(hex, n)
def get_vars(x):
    y = str(x)
    v_1,v_2 = [],[]
    if ':' in y:
        n = str(x)[1:-1].split(',')
        for i in range(0,len(n)):
            v = str(n[i]).replace('"','').replace("'",'').replace(' ','').split(':')
            v_1.append(v[0])
            v_2.append(v[1])
    return v_1,v_2
def get_c(i):
    c = ''
    if i != 0:
        c = ','
    return c
def js_qu(x):
    if type(x) is not list:
        return '"'+str(x)+'"'
    ls = []
    for i in range(0,len(x)):
        ls.append('"'+str(x[i])+'"')
    return x
def js_it(x):
    return json.loads(str(x).replace("'",'"'))
def join_it(x,y):
    return str(x)+str(y)
def get_list(x,y):
    x = t_f_js_check(x)
    for i in range(0,len(y)):
        x = str(x)[:-1] + get_c(i)+ str(y[i])+str(x)[-1]
    return x
def gen_index(y):
    n = ['indexed', 'internalType', 'name', 'type']
    z = y['type'] + ' '+y['name']
    if z not in all_vars:
        if y['name'] == '':
            if y['type'] not in types:
                types.append(z.replace(' ',''))
        else:
            if z not in all_vars:
                all_vars.append(z)
    if 'indexed' in y:
        if y['indexed'] == 'False':
            if z not in non_varis:
                non_varis.append(z)
        else:
            z = y['type'] + ' indexed '+y['name']
            if z not in ind_varis:
                ind_varis.append(z)

    return z
def get_fun(x,y,z):
    na = ['inputs','outputs']
    n = x[y]
    fun = str(y)+'()'
    kek = ''
    for i in range(0,len(na)):
        i_o = na[i]
        if i_o in n:
            nn = n[i_o]
            if str(nn) != '[]':
            
                
                fun = get_list(fun,nn)
        if i == 0:
            fun = fun + ' '+z +' returns ()'
        if i == 1:
            fun = fun
    fun = 'function '+fun+'{};'

    return str(fun).replace(' )',')')
def get_event(x,y):
    na = ['inputs','outputs']
    fun = 'event '+str(y)+'()'
    v =[]
    for i in range(0,len(na)):
        i_o = na[i]
        if i_o in na:
            for ii in range(0,len(x[i_o])):
                v.append(gen_index(js_it(t_f_js_check(x[i_o][ii]))))
            fun = get_list(fun,v)
            
    return str(fun).replace(')',');')
def get_map(x,y):
    na = ["function","fallback"]
    z = ''
    inputs = []
    out = []
    for i in range(0,len(x['inputs'])):
        inputs.append(x['inputs'][i]['type'])
    for i in range(0,len(x['outputs'])):
        out.append(x['outputs'][i]['type'])
    if len(inputs) == 2 and len(out) == 1:
        z = 'mapping ('+str(inputs[0])+' => mapping ('+str(inputs[1])+' => '+str(out[0])+')) ' +str(y)
    elif len(inputs) == 1 and len(out) == 1:
        z = 'mapping ('+str(inputs[0])+' => '+str(out[0])+') '+str(y)
    return z+';'
def t_f_js_check(x):
    y = str(x)
    tf = ['True','False'] 
    sides = [' ','"',"'"]
    for i in range(0,len(tf)):
        n_tf = tf[i]
        if n_tf in str(y):
            for ii in range(0,len(sides)):
                va = [n_tf+sides[ii],sides[ii]+n_tf]
                for iii in range(0,2):
                    v = va[iii]
                    while str(v) in str(y):
                        y = str(y).replace(v,n_tf)
            y = js_it(str(y).replace(n_tf,js_qu(n_tf)))
    return y
def func_break():
    new = []
    for i in range(0,len(funs)):
        x = funs[i]
        y = x.replace('function ','').split(') ')[0]
        y = y.split('(')
        name = y[0]
        ins = y[1]
        ins = '["'+str(ins).replace("'",'"').replace(',','","').replace(' "," ','","')+'"]'
        n = js_it(ins)
        for ii in range(0,len(n)):
            kek_funs.append(str(name)+'('+n[ii].split(' ')[0]+')')
def islist(x):
    if type(x) is not list:
        return False
    return True
def disp_it(x):
    new = ''
    x = js_it(x)
    for ii in range(0,len(x)):
        n = x[ii]
        new =new+'\n'+ n
    return new
def check_sum(x):
    return Web3.toChecksumAddress(str(x))
def mains(x):
    from web3 import Web3
    global net,ch_id,main,file,w3,last_api,c_k,hashs_js,expo,dec
    hashs_js = ''
    last_api = [0,0]
    scan = ['avax','polygon','ethereum','cronos_test','optimism','binance']
    main = {
        'avax':{'net':'https://api.avax.network/ext/bc/C/rpc','chain':'43114','main':'AVAX'},
            'polygon':{'net':'https://polygon-rpc.com/','chain':'137','main':'MATIC'},
            'ethereum':{'net':'https://mainnet.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161','chain':'1','main':'ETH'},
            'cronos_test':{'net':'https://cronos-testnet-3.crypto.org:8545/','chain':'338','main':'TCRO'},
            'optimism':{'net':'https://kovan.optimism.io','chain':'69','main':'OPT'},
            'binance':{'net':'https://bsc-dataseed.binance.org/','chain':'56','main':'bsc'}
            }
    expo = ''
    dec = ''
    main = main[x]
    net,ch_id,main,file,w3 = main['net'],main['chain'],main['main'],str(x)+'.txt',Web3(Web3.HTTPProvider(main['net']))
    c_k = 0
    return net,ch_id,main,file,w3
def func_grab():
    varis['types'] = types
    varis['all'] = all_vars
    varis['indexed'] = ind_varis
    varis["non_indexed"]=non_varis
    func_break()

def reques_timer():
    import datetime
    now = datetime.datetime.now().timestamp()
    i = (float(now) - float(reader('last.txt')))
    if float(i) < float(0.3):
        return (float(0.3) - float(i)), now
    return 0, now
def wall_call(add,B_L,B_G):
    link = wall_sup(add,B_L,B_G)
    JS = sites(link)
    js = JS["result"]
    return js
def first_last(js,X):
    Y = X
    try:
        W = js[0]
        F = W['timeStamp']
        B_L = W['blockNumber']
        W = js[-1]
        L = W['timeStamp']
        B_G = W['blockNumber']   
        Y = F,L,B_L,B_G
        if X !=0:
            if int(X[3]) == int(B_G) :
                return Y,1
            else:
                return Y,0
    except:
        return Y,-1
def reader_B(file):
    with open(file, 'r',encoding='UTF-8') as f:
        text = f.read()
        return text
def reader_C(file):
    with open(file, 'r',encoding='utf-8-sig') as f:
        text = f.read()
        return text
def pen_B(paper, place):
    
    with open(place, 'w',encoding='UTF-8') as f:
        f.write(str(paper))
        f.close()
        return
def sites(A):
    U = [A]
    for url in U:
        X = str(U[0])
        i,now = reques_timer()
        time.sleep(i)
        r = requests.get(X)
        pen(str(now),'last.txt')
        PS = r.text
        JS = json.loads(PS)
    return JS
def keys():
    if scanners == 'bscscan.com':
        key = 'JYVRVFFC32H2ZSKDY1JZKNY7XV1Y5MCJHM'
    elif scanners == 'polygonscan.com':
        key = 'S6X6NY29X4ARWRVSIZJTG1PJS4IG86B3WJ'
    elif scanners == 'ftmscan.com':
        key = 'WU2C3NZAQC9QT299HU5BF7P8QCYX39W327'
    elif scanners == 'moonbeam.moonscan.io':
        key = '5WVKC1UGJ3JMWQZQAT8471ZXT3UJVFDF4N'
    else:
        key = '4VK8PEWQN4TU4T5AV5ZRZGGPFD52N2HTM1'
    return key
def block(A):
    key = keys()
    U = 'https://api.etherscan.io/api?module=block&action=getblocknobytime&timestamp='+str(A)+'&closest=before&apikey='+str(key)
    
    JS = sites(U)
    Bl = JS['result']
    return Bl
def exists_js(file):
    try:
        f = reader_B(file)
        if f !='':
            try:
                A = projs(f)
                
                return A
            except IOError:
                print('json not formed')
        else:
            f = '[]'
            return f
    except IOError:
        pen('[]',file)
        return json.loads('[]')
def dirs_main():
    path = "/home4/putkoff/gtsgate.com/script/wallets"
    # Check current working directory.
    retval = os.getcwd()
    print ("Current working directory %s" % retval)
    # Now change the directory
    os.chdir(path)
    # Check current working directory.
    retval = os.getcwd()
    print("Directory changed successfully %s" % retval)
    #print("Directory '% s' created" % directory)
    return
def dirs_A(fname):
    path = '/home4/putkoff/gtsgate.com/script/wallets/wallets/'+str(fname)
    # Check current working directory.
    retval = os.getcwd()
    print ("Current working directory %s" % retval)
    # Now change the directory
    os.chdir(path)
    # Check current working directory.
    retval = os.getcwd()
    print("Directory changed successfully %s" % retval)
    #print("Directory '% s' created" % directory)
    return 
def check_dirs(fname):
    path = str(fname)
    isdir = os.path.isdir(path)
    return isdir
def check_files(fname):
    isfile = os.path.isfile(fname) 
def change_dir(f):
    path = "/home4/putkoff/gtsgate.com/script/wallets" + '/'+str(f)
    retval = os.getcwd()
    print ("Current working directory %s" % retval)
    os.chdir(path)
    retval = os.getcwd()
    print("Directory changed successfully %s" % retval)
    return
def mkdirs(f):
    import os  
    directory = f
    parent_dir = get_home()
    path = os.path.join(parent_dir, directory)  
    os.mkdir(path)  
    print("Directory '% s' created" % directory)
    return path
def dirs_B(U):   
    parent_dir = U
    path = os.chdir(parent_dir)
    os.chdir(str(path))
    print(path)
    return path
def get_ti():
    import datetime
    T_S = datetime.datetime.now().timestamp()
    pen(str(T_S),'last.txt')
    T_S_D = str(datetime.datetime.now())[0:10]
    day = int(int(T_S) - int(86400))
    B_L = block(day)
    B_G = block(int(T_S))

    TS = '{"TS":["'+str(T_S)+'","'+str(T_S_D)+'","'+str(B_L)+'","'+str(B_G)+'"]}'
    pen(TS, 'T_S_pow.py')
    return B_L,B_G,T_S,T_S_D,day
def tryit_js(js):
    try:
        js = projs(str(js))
        return js
    except:
        
        return 0
def tryit_js(js):
    try:
        js = projs(str(js))
        return js
    except:
        
        return 0
def countit(array,delim):
    array_count = str(array)
    len_count_A = len(array_count)
    array_short = array_count.replace(delim,"")
    len_count_B = len(array_short)
    arr_num = len_count_A - len_count_B
    arr_num = arr_num
    return arr_num
def count_js(B):
    N = 0
    M = 0
    while M != -1:
        M,L_B = tryit(B,N)
        N = N + 1
    L_B = L_B - 1
    return L_B
def sites(A):
    U = [A]
    for url in U:
        X = str(U[0])
        i,now = reques_timer()
        time.sleep(i)
        r = requests.get(X)
        pen(str(now),'last.txt')
        PS = r.text
        JS = json.loads(PS)
    return JS
def supply(add,Ad_pa):
    key = keys()
    CONT_SUP = 'http://api.etherscan.io/api?module=account&action=tokenbalance&contractaddress='+str(add).lower()+'&address='+str(Ad_pa).lower()+'&tag=latest&apikey='+key
    return  CONT_SUP
def wall_sup(Ad_pa,B_L,B_G):
    key = keys()
    WALL_TR = 'http://api.etherscan.io/api?module=account&action=tokentx&address='+str(Ad_pa)+'&startblock='+str(B_L)+'&endblock='+str(B_G)+'&sort=asc&apikey='+key
    return WALL_TR
def tok_sup(Ad_pa):
    key = keys()
    TOK_LP = 'https://api-cn.etherscan.com/api?module=stats&action=tokensupply&contractaddress=' + str(Ad_pa).lower() + '&apikey='+key
    return TOK_LP
def JS_prep(J):
    import gc
    gc.collect()
    J = str(J).replace(' ','').replace("'",'"').replace(']','').replace('[','').replace('}{','},{').replace('or"s','ors').replace('[,','[').replace('None','')
    
    if str(J) != ' ' and str(J) != '' and str(J) != '[]'and str(J) != '{}':
        J = str(J)
        L = int(len(J))
        i = int(-1)
        N,M = tryit(J,i)
        if int(N) == int(0):
            while (int(N) - int(L)) != int(0):
                if J[i] == '' or J[i] == ',' or J[i] == ']' or J[i] == ' ':
                    J = J[:-1]
                    #L = int(len(J))
                    
                    N = timer(N)
                else:
                    N = int(L)
        L = int(len(J))
        i = int(0)
        N,M = tryit(J,i)
        if int(N) == int(0):
            while (int(N) - int(L)) !=int(0):
                if J[i] == '' or J[i] == ',' or J[i] == ']' or J[i] == ' ':
                    J = J[1:]
                    #L = int(len(J))
                    
                    N = timer(N)
                else:
                    N = int(L)
    return J
def JS_prep_B(A):
    A = str(A).replace(' ','').replace("'",'"').replace(',}','}').replace('{,','{').replace('}{','},{').replace('or"s','ors').replace('[,','[').replace('None','').replace('}','').replace('{','').replace(']','').replace('[','')
    return A
def projs(A):
    import gc
    
    J = JS_prep(A)
    if J == '' or J == ' ':
        return J
    J =  str(J).replace('"tokenName":"","','"tokenName":"0","').replace('"tokenSymbol":"","','"tokenSymbol":"0","').replace('"tokenDecimal":"","','"tokenDecimal":"0","')
    J =  str(J).replace('":"","','":"0","')
    J =  str(J).replace('""','"').replace(',,',',')
    gc.collect()
    J = str('[' +J+ ']').replace(' ','')
    J =  str(J).replace('[,','[').replace(',]',']')
    
    pen_B(str(J),'recent.txt')
    return json.loads(J)
def projs_B(A):
    J = JS_prep_B(A)
    if J == '':
        return J
    
    while J[-1] == '' or J[-1] == ',' or J[-1] == ']' or J[-1] == ' ':
        J = J[:-1]
    while J[0] == '' or J[0] == ',' or J[0] == ']' or J[0] == ' ':
        J = J[1:]
    J = '{' + str(J) + '}'
    return json.loads(J)
def timermin(N):
    N = N - 1
    return N
def find_point(B,D,X):
    N = 0
    done = 1
    L = count_js(B)
    while done != 0:
        C = B[N]
        if C[D] == str(X):
            done = 0
        if int(N) == int(L):
            return ''
        print(N,L)
        N = timer(N)
    N = int(N)
    B = B[N:]
    
    return B
def check_comp(J):
    J = projs(J)
    tr,N = tryit(J,0)
    if tr != -1:
        B = J[0]
        E = B['blockNumber']
        F = B['timeStamp']        
        D = J[-1]
        G = D['blockNumber']
        H = D['timeStamp']
        if int(F) > int(H):
            J = reverse(J)
    return projs(J)
def JS_rev(js):
    pen_B(js,'other1.txt')
    js = projs(js)
    L = count_js(js)
    js = js[L:]
    pen_B(js,'other.txt')
    return js
def check_blk(f,bl,ts):
    J = exists_js(f)
    tr,N = tryit(J,0)
    if int(tr) == int(0):
        J = check_comp(J)
        B = J[0]
        E = B['blockNumber']
        F = B['timeStamp']        
        D = J[-1]
        G = D['blockNumber']
        H = D['timeStamp']
        
        #if int(F) < int(day):
            #J = find_point(J,'timeStamp',int(day))
        return J,G,H
    
    return J,bl,ts
def crunch(js_A,js_B):
    JS_A = JS_prep(str(JS_A))
    JS_B = JS_prep(str(JS_B))
    JS_C = str(JS_A) + str(JS_B)
    return JS_C
def rev_js(js):
    L = int(count_js(js)) - int(1)
    A = js[0:L]
    B = js[-1]
    C = crunch(A,B)
    js = projs(str(C))
    return js
def get_stamps(js):
    if len(str(js)) > 2:
        A = js[0]
        A = A['timeStamp']
        L = count_js(js)
        B = js[L]
        B = B['timeStamp']
        return A,B
    return js
def reverse(js):
    print('reversing')
    js = projs(js)
    L_N = count_js(js)
    X = ''
    while int(L_N) != int(-1):
        X = str(X) +str(js[L_N])+','
        js = js[0:L_N]
        L_N = timermin(L_N)
    return projs(X)
def wall_call(add,B_L,B_G):
    link = wall_sup(add,B_L,B_G)
    JS = sites(link)
    js = JS["result"]
    return js
def hashit(js,day,T_S,bl,add,fname):
    Ts = T_S
    pairs = ''
    print('hashing it')
    js = projs(js)
    
    tr = 0
    L_B = count_js(js)
    H_js = exists_js('hashs.txt')
    H = reader('hashs.txt')
    B = ''
    L_N = 0
    if fname == 'burn_wall.txt':
        arr = ''
        L = count_js(pairs)
        N = 0
        while int(N) != int(L):
            P = pairs[N]
            arrs = array[P]
            arr = arr + ',"'+arrs['pair']+'"\n'
            arr = str(arr).lower()
            N = N + 1
        arr = '['+str(arr)+']'
        arr = str(arr).replace('[,','[')
        arr = json.loads(arr)
        while int(L_N) != int(L_B) and tr != -1:
            
            line = js[L_N]
            Ts = line["timeStamp"]
            cont = line['contractAddress']
            B_L = line['blockNumber']
            if cont.lower() in arr and int(Ts) >= int(day) and int(Ts) > int(T_S) and int(B_L) > int(bl):
                if line['to'].lower() == add.lower() or line['from'].lower() == add.lower():
                    B = str(B)+','+str(line)+'\n'
                    if line['hash'].lower() not in H_js:
                        H =H.lower()+ ',"'+str(line['hash']).lower()+'"\n'
                        H_js = '['+str(H)+']'
                        H_js = str(H_js).replace('[,','[')
                        H_js = json.loads(H_js)
                    #print(L_N,L_B)
            L_N = timer(L_N)
    else:
        while int(L_N) != int(L_B) and tr != -1:
            tr,L_N = tryit(js,L_N)
            line = js[L_N]
            Ts = line["timeStamp"]
            cont = line['contractAddress']
            B_L = line['blockNumber']
            if line['hash'].lower() not in H_js and int(Ts) >= int(T_S) and int(B_L) > int(bl):
                if line['to'].lower() == add.lower() or line['from'].lower() == add.lower():
                    B = str(B)+','+str(line)+'\n'
            L_N = timer(L_N)
            #print(L_N,L_B,fname,Ts,T_S)
    pen(H,'hashs.txt')
    tr,i = tryit(B,0)
    if int(tr) != int(-1):
        if B[0] == ',':
            B = B[1:]
        B = projs(B)
    
    return B,Ts
    
def prices(tok_A, tok_B,array_specs):
    
    array_specs = json.loads(array_specs)
    tok_A_allias = array_specs[str(tok_A)]
    tok_B_allias = array_specs[str(tok_B)]
    tok_A_allias = tok_A_allias['name_price']
    tok_B_allias = tok_B_allias['name_price']
    price_A = int(1)
    price_B = int(1)
    si = int(2)
    times = int(0)
    balance_C = ''
    num_tok = int(0)
    page=''
    currencies = [
        'https://api.coingecko.com/api/v3/simple/price?ids='+str(tok_A_allias)+'&vs_currencies=usd',
        'https://api.coingecko.com/api/v3/simple/price?ids='+str(tok_B_allias)+'&vs_currencies=usd'
        ]
    times = si
    while times > 0:
        for url in currencies:
            site_st = str(currencies[num_tok])
            if site_st =='https://api.coingecko.com/api/v3/simple/price?ids=take_other&vs_currencies=usd' or site_st =='https://api.coingecko.com/api/v3/simple/price?ids=dollar&vs_currencies=usd':
                new = site_st.replace('&vs_currencies=usd','')
                new = new.replace('https://api.coingecko.com/api/v3/simple/price?ids=','')
                price = new
            else:                    
                new = site_st.replace('&vs_currencies=usd','')
                new = new.replace('https://api.coingecko.com/api/v3/simple/price?ids=','')
                r = requests.get(url)
                page_source = r.text
                page_source = json.loads(page_source)
                price = page_source[new]
                price = price["usd"]
                new = str(new)
                price = str(price)
            if num_tok == int(0):
                toks = tok_A
                price_A = price
            else:
                toks = tok_B
                price_B = price
            num_tok = num_tok + int(1)
            times = times - int(1)
    if tok_A_allias == 'dollar':
        price_A = float(1.00)
    if tok_B_allias == 'dollar':
        price_B = float(1.00)
    return price_A, price_B
def works(worksheet, tok_A_B_add, tok_A, tok_B, tok_A_B, balance_A, balance_B, balance_C, price_A, price_B, tok_A_T, tok_B_T,tok_U_T,curr_val_B, avg_eth,num):
    if balance_A == float(0):
        balance_A = int(1)
    if balance_B == float(0):
        balance_B = int(1)
    if balance_C == float(0):
        balance_C = int(1)
    if price_B == "take_other" and price_A == 'take_other':
        price_A = int(1)
        price_B = int(1)
    if price_B == "take_other":
        if balance_B != int(0) and balance_B != float(0.0):
            price_B = (float(price_A)*float(balance_A))/float(balance_B)
            
        else:
            price_B = int(1)
    if price_A == "take_other":
        if balance_A != int(0) and balance_A != float(0.0) and (0 - float(balance_A)) < float(0.0):
            price_A = (float(price_B)*float(balance_B))/float(balance_A)
            
        else:
            price_A = int(1)
    liq_A = float(balance_A) * float(price_A)
    liq_B = float(balance_B) * float(price_B)
    tot_liq = liq_A + liq_B
    if price_A == int(0):
        price_A = liq_B / tok_A_T
    if price_B == int(0):
        price_B = liq_A / tok_B_T
    perc_A = liq_A/tot_liq
    perc_B = liq_B/tot_liq
    tok_A_per_UNI = float(balance_A)/float(balance_C)
    tok_vol_A = (float(tok_A_T) * float(price_A))
    tok_A_fee = float(tok_vol_A) * float(0.003)
    tok_per_UNI=tok_A_per_UNI
    tok_B_per_UNI = float(balance_B)/float(balance_C)
    if curr_val_B != float(0.0):
        tok_vol_B = float(curr_val_B)
    else:
        tok_vol_B = float(tok_B_T)
    tok_B_fee = tok_vol_B * float(0.003)
    tok_per_UNI = tok_B_per_UNI
    per_K = int(1000)/tot_liq
    per_ten_K = int(10000)/tot_liq
    per_K_A = per_K*tok_A_fee
    per_ten_K_A = per_ten_K*tok_A_fee
    per_K_B = per_K*tok_B_fee
    per_ten_K_B = per_ten_K*tok_B_fee
    cells = num + int(2)
    alpha_cell = int(0)
    cell = str(alpha[alpha_cell]) + str(cells)
    print(cell)
    timer = int(-1)
    price_diff_B = int(0)
    price_diff_A = int(0)
    price_diff_T = int(0)
    sheet_hist = exists(path_bal+'/sheet_hist.txt')
    sheet_keep = "tok_A_B", "balance_A", "balance_B", "balance_C", "price_A", "price_B", "liq_A", "liq_B", "perc_A", "perc_B", "tot_liq", "tok_A_T", "tok_B_T", "tok_U_T", "tok_A_per_UNI", "tok_B_per_UNI", "tok_vol_A", "tok_vol_B", "tok_A_fee", "tok_B_fee", "per_K_A", "per_ten_K_A", "per_K_B", "per_ten_K_B", "tok_A_B_add", "price_diff_A", "price_diff_B", "hours"   
    
    sheet_vari = str(tok_A_B), str(balance_A), str(balance_B), str(balance_C), str(price_A), str(price_B), str(liq_A), str(liq_B), str(perc_A), str(perc_B), str(tot_liq), str(tok_A_T), str(tok_B_T), str(tok_U_T), str(tok_A_per_UNI), str(tok_B_per_UNI), str(tok_vol_A), str(tok_vol_B), str(tok_A_fee), str(tok_B_fee), str(per_K_A), str(per_ten_K_A), str(per_K_B), str(per_ten_K_B), str("https://info.uniswap.org/pair/"+tok_A_B_add), str(price_diff_A), str(price_diff_B), str('24')    
    len_keet = countit(str(sheet_keep), ',')
    len_keet = len_keet + int(1)
    print(len_keet)
    num_keet = int(0)
    len_sheet = countit(str(sheet_vari), ',')
    len_sheet = len_sheet + int(1)
    
    num_sheet = int(0)
    while num_sheet != len_sheet:
        worksheet = worksheet +'\n'+'worksheet.write('+"'"+cell+"'"+', '+"'"+sheet_vari[num_sheet]+"'"+')'
        if num_sheet < int(14):
            if sheet_keep[num_sheet] == 'tok_A_B':
                sheet_hist = str(sheet_hist) + '\n"'+sheet_vari[num_sheet] +'":{'
            elif sheet_keep[num_sheet] == "tok_U_T":
                sheet_hist = str(sheet_hist) + '"'+sheet_keep[num_sheet] +'":"'+sheet_vari[num_sheet]+'"},'
            else:
                sheet_hist = str(sheet_hist) + '"'+sheet_keep[num_sheet] +'":"'+sheet_vari[num_sheet]+'",'
        alpha_cell = alpha_cell + int(1)
        cell = str(alpha[alpha_cell]) + str(cells)
        num_sheet = num_sheet + int(1)
    pen(sheet_hist,path_bal+'/sheet_hist.txt')
    Pr = reader(path_price+'/price.txt')
    P = projs_B(Pr)
    if tok[0] not in P:
        Pr = str(Pr) +'"'+str(tok[0])+'":"'+str(price_A)+'",'
    if tok[1] not in P:
        Pr = str(Pr) +'"'+str(tok[1])+'":"'+str(price_B)+'",'
    pen(Pr,path_price+'/price.txt')
    return worksheet
def renum(old,A_js,day,T_S,eth_avg):
    print('renum',day)
    A = projs(A_js)
    eth_chart = ''
    count = 0
    prev_B = int(day)
    A_txt = old
    B = int(day)
    prev_price = eth_avg
    C = 0
    
    while C == 1:
        
        if str(B) not in A:
            B = timer(B)
        else:
            prev_price = float(A[str(B)])
            while int(prev_B) >= int(B):
                print(prev_B)
                eth_chart = ',"'+str(prev_B)+'":"'+str(prev_price)+'"\n'+str(eth_chart)
                
                prev_B = timer(int(prev_B))
            C = 0
    while C == 0 and int(B) != int(T_S):
        
        if str(B) in A and int(count) == int(0):
            eth_chart = ',"'+str(B)+'":"'+str(A[str(B)])+'"\n'+str(eth_chart)
            prev_price = float(A[str(B)])
            prev_B = int(B)
        elif str(B) in A and int(count) != int(0):
            curr_price = float(A[str(B)])
            eth_avg = (float(prev_price)+ float(curr_price))/float(2)
            while int(prev_B) != int(B):
                eth_chart = ',"'+str(prev_B)+'":"'+str(eth_avg)+'"\n'+str(eth_chart)
                prev_B = int(timer(prev_B))
            B = int(prev_B)
            count = int(0)
        elif str(B) not in A:
            count = timer(count)
        B = timer(B)
        
    if int(B) == int(T_S) and int(count) != int(0):
        while int(prev_B) < int(T_S):
            
            prev_B = timer(int(prev_B))
            eth_chart = ',"'+str(prev_B)+'":"'+str(prev_price)+'"\n'+str(eth_chart)
        
    eth_chart = '"last":"'+str(T_S)+'"\n'+',"avg":"'+str(eth_avg)+'"\n'+str(eth_chart) 
    pen(str(eth_chart),path_price+'/eth_price.txt')
    return eth_chart
def findit(js,X):
    L_eth = count_js(js)
    N = 0
    while js[N] != str(X):
        N = timer(N)
    return N
def organ(js):
    js
    return js
def add_brac(S):
    return str('{'+str(S)+'}')
def rem_comm(S):
    S = str(S)
    if str(S[0]) == ',':
        S = str(S)[1:]
    if str(S[-1]) == ',':
        S = str(S)[:-1]
   
    return S
def ch_quote(S):
    return str(str(S).replace("'",'"'))
def eat_till_comma(ls):
    s_ls = str(ls)
    og_len = len(str(ls))
    c_spl = str(ls).split(',')[-1]
    if '}' in c_spl:
        return ls
    i = 0
    while for_it(i,len(c_spl)) == True:
        s_ls = s_ls[:-1]
        if s_ls[-1] == ']':
            if s_ls[0] == '[':
                s_ls = s_ls[1:]
        if s_ls[-1] != ' ' and s_ls[-1] != ',' and s_ls[-1] != '\n':
            return s_ls
        if s_ls[-1] == ',':
            return s_ls[:-1]
        i = timer(i)
        print(i)
    x = str(s_ls).replace("'",'"')
    print(x)
    return json.loads(x)
def att_it(x):
    toJSON = json.dumps(list(x))
    data = json.loads(toJSON)
    prnt(data)
def for_it(i,k):
    if int(i) < int(k):
        return True
    return False
def del_line(ls,k):
    n_ls = []
    for i in range(0,len(ls)):
        if int(i) != int(k):
            n_ls.append(ls[i])
    return n_ls
def list_it(k):
    div = ff.change_gears('nebula/')
    dirs = os.listdir()
    for i in range(0,len(dirs)):
        n = ff.reader(dirs[i])
        n = eat_till_comma(n)
        if n[-1] == ',':
            n = n[:-1]
        x = str('['+n+']').replace("HexBytes('0x","'").replace("')], '","'],'").replace("'), '","','").replace("AttributeDict({",'{').replace('})','}').replace(',]',']').replace("'",'"').replace(' False','False').replace(' True','True').replace('True ','True').replace('True','"True"').replace('False ','False').replace('False','"False"').replace('""','"').replace('[[','[').replace(']]',']')
        
        n = json.loads(x)
        ll = len(n)
        c = 0
        ii = 0
        while for_it(ii,ll) != False:
            n_l = n[ii]
            if n_l["blockNumber"] >= k:
                n = del_line(n,ii)
            ll = len(n)
            ii = timer(ii)
            print(ii,ll)
        print(dirs)
        ff.pen(n,dirs[i])
    ff.change_gears(div)

def grab_glob():
    global t_js
    return t_js
def save_glob(t_js,t_ls):
    change_glob('t_js',t_js)
def count_it(x):
    for i in range(0,len(x)):
        fi_pg(AttributeDict(str(x[i]).replace("'",'"').replace(' False','"False"').replace(' True','"True"').replace('AttributeDict(','').replace('})','}'))[0])
def fi_pg(n):
    t_js = grab_glob()
    print(n)
    t = str(f.read_hex(n.topics[0]))
    t = t.replace('0x','')
    print(t)
    if str(t) not in t_js:
        x = str(str(t_js)[:-1]+',"'+str(t)+'":[]}').replace("'",'"').replace(' False','"False"').replace(' True','"True"')
        t_js = json.loads(x)
    t_js[str(t)].append(n)
    change_glob('t_js',t_js)
def fi(x):
    filt = w3.eth.filter(x)
    event_logs = w3.eth.get_filter_logs(filt.filter_id)
    json.dumps(event_logs[0])
def get_home():
    x = os.path.dirname(os.path.realpath(__file__))
    slash = '\\'
    if slash not in x:
        slash = '/'
    change_glob('slash',slash)
    return x
def create_path(x,y):
    c = slash
    if x[-1] == slash:
        x = x[:-1]
    if y[0] == slash:
        y = y[1:]
    x = str(x)+ c + str(y)
    return x
def foldersave():
    B_L,B_G,Ts,date,day = f_eth.get_ti()
    foldate = ['fri','sat','sun','mon','tues','wed','thur']
    sec = float(1)
    mi = float(60)
    hour = float(60*mi)
    day = float(24*hour)
    week = float(7*day)
    fri = 1609510651.1613681
    print('fri',fri)
    since = (float(Ts)-(float(fri)))
    D = mi,hour,day,week
    D_2 = 'sec,hour,day,week'
    D_3 = D_2.split(',')
    N = 0
    jas = ''
    while N <= int(3):
        i = float(since)/float(D[N])
        jas = jas+',"'+str(D_3[N])+'":"'+str(float(i))+'"'
        N = f_eth.timer(N)
        TSH = str(f_eth.ch_quote(f_eth.add_brac(f_eth.rem_comm(jas))))
        print(i,TSH,N)
        timesheet = json.loads(TSH)
    days = int(float(timesheet['day']))
    rem = days % len(foldate)
    date = '_'+str(date).replace('-','_')
    path_date = foldate[rem]+date
    path_date = create_path('txn_hist',path_date)
    path_price = create_path(path_date,'price')
    path_bal = create_path(path_date,'bal')
    path_track = create_path(path_date,'track')
    path_curr = create_path(path_date,'curr')
    path_var = create_path('utils','variables')
    X = [path_date, path_price,path_bal,path_track,path_curr,path_var]
    X_name = 'path_date','path_price','path_bal','path_track','path_curr','path_var'
    paths = [path_date,home+path_price,home+path_bal,home+path_track,home+path_curr,home+path_var]
    i = 0
    for i in range(0,len(X)):
        x = X[i]
        print(x)
        A= f_eth.check_dirs(x)
        print(A)
        if A == False:
            print('we change it')
            f_eth.mkdirs(x)
        path = create_path(home,x)
        change_glob(X_name[i],path)
        print(path)
def change_glob(x,v):
    globals()[x] = v
