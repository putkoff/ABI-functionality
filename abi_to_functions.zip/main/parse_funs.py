import functions as ff
import json
def parse_it(add,funs):
    beg = "from web3 import Web3\nimport p_k as key\nimport json\nimport functions as f\n"
    end = '\nglobal scanners,add,abi,cont,account_1,scanners,net,ch_id,main_tok,file,w3,network,nonce\nadd = "'+str(add)+'"\nabi = f.reader_C("abi_fold/"+str(add)+".json")\nmain_all = f.mains()\nscanners,net,ch_id,main_tok,file,w3,network = main_all\n\ncont = w3.eth.contract(add,abi = abi)\naccount_1 = w3.eth.account.privateKeyToAccount(key.p)\nnonce = w3.eth.getTransactionCount(account_1.address)'
    symbol = 'cont'
    call = []
    asks = []
    fun_sheet = beg.replace("'",'"')
    view_sheet = 'def view_all():\n\t'
    for i in range(0,len(funs)):
        n = str(funs[i].split('function ')[1].split(')')[0]+')').replace('[]','ls').replace(' ,',',').replace(', ',',').replace(' )',')').replace(' ','_')
        n = n.replace('_)',')')
        if 'view' in str(funs[i].split('function ')[1].split(')')[1]):
            asks.append(n)
            fun_sheet = fun_sheet + 'def '+n+':\n\tx = '+str(symbol)+'.functions.'+n+'.call()\n\tf.pen(x,"ask.txt")\n\tprint("'+str(funs[i].split('(')[0].split('function ')[1])+'"," is ",x)\n\treturn x\n'
            if '()' in n:
                view_sheet = view_sheet +  'print("'+str(funs[i].split('(')[0].split('function ')[1])+'",":",'+str(symbol)+'.functions.'+n+'.call())\n\t'
        else:
            call.append(n)
            fun_sheet = fun_sheet + 'def '+n+':\n\treturn '+str(symbol)+'.functions.'+n+".buildTransaction({'gasPrice': 60000000000,'gas':402640,'from': account_1.address,'nonce': nonce,'chainId': int(ch_id)})\n"
    fun_sheet = fun_sheet +view_sheet+ end
    
    
    #for i in range(0,len(calls)):
    #    if '()' in str(calls[i]):
    #        asks.append(calls[i])
    #        n = calls[i]
    #call = []
    #for i in range(0,len(calls)):
    #    if calls[i] not in asks:
    #        call.append(calls[i])
    #        n = calls[i]
    #
    get_em = [asks,call]
    fun_all = []
    for k in range(0,len(get_em)):
        for i in range(0,len(get_em[k])):
            n = 'funs.'+get_em[k][i].replace('[]','ls').replace(' ,',',').replace(', ',',').replace(' ','_')
            fun_all.append(n)
    return funs,asks,call,fun_all,fun_sheet
