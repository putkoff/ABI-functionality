import functions as f
from dotenv import load_dotenv
import os
load_dotenv()
if exists('new_key.txt') == True:
	load_dotenv(str(f.reader('new_key.txt')))
p = os.environ.get("privateKey")

