import functions as f
def api_key():
    if scanners == 'bscscan.com':
        x = 'JYVRVFFC32H2ZSKDY1JZKNY7XV1Y5MCJHM'
    elif scanners == 'polygonscan.com':
        x = 'S6X6NY29X4ARWRVSIZJTG1PJS4IG86B3WJ'
    elif scanners == 'ftmscan.com':
        x = 'WU2C3NZAQC9QT299HU5BF7P8QCYX39W327'
    elif scanners == 'moonbeam.moonscan.io':
        x = '5WVKC1UGJ3JMWQZQAT8471ZXT3UJVFDF4N'
    else:
        x = '4VK8PEWQN4TU4T5AV5ZRZGGPFD52N2HTM1'
    return x
def get_abi():
    return f.sites('https://'+str(scanners)+'/api?module=contract&action=getabi&address='+check_sum(str(add))+'&apikey='+str(api_key())) 
def check_sum(x):
    return w3.toChecksumAddress(x)
global scanners,net,ch_id,main_tok,file,w3,network,add
scanners,net,ch_id,main_tok,file,w3,network = f.mains()
